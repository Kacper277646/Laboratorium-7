package com.example.laboratorium_7

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.example.laboratorium_7.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btn).setOnClickListener(View.OnClickListener {

            if(findViewById<EditText>(R.id.et).text.toString().equals("nav")) {
                val intent = Intent(this@MainActivity, NavActivity::class.java)
                startActivity(intent)
            } else {
                val intent = Intent(this@MainActivity, MainActivity2::class.java)

                val imie: String = findViewById<EditText>(R.id.et).text.toString()

                intent.putExtra("name", imie)

                startActivity(intent)
            }

        })

    }
}